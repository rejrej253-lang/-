# MaxBoost APK — analysis workflow

This repository template creates a read-only static analysis report for the original APK.
It deliberately does **not** remove ad SDKs or patch Smali yet: deleting whole SDK packages or
manifest components blindly can break app startup, audio services, VIP/purchase flows, or UI.

## Setup

1. Create a private GitHub repository (the APK is a third-party binary; avoid publishing it publicly).
2. Upload the original file as `app/MaxBoost.apk` and commit it.
3. Open **Actions → MaxBoost APK - analyze → Run workflow**.
4. Download the `maxboost-ad-analysis` artifact from the completed run.

The workflow decodes the APK with APKTool and reports references to Google Mobile Ads, Meta
Audience Network, Pangle/ByteDance, Coocent Promotion, and AppLovin. It does not change the APK.

## Why no automatic ad-removal patch yet?

An SDK being present does not prove every call is an ad call. We need to identify the app's own
classes/methods that initialize and request ads, and distinguish those from audio, settings,
subscription, and VIP logic. The report is the safe first pass; a targeted patch can then be
added against the exact methods found in this build.

Keep the original APK unchanged. Rebuilt APKs require a new signature; Android will generally
not install them as an update over the store-signed original unless the signing key matches.
